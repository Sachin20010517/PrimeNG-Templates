import { Component } from '@angular/core';

@Component({
    templateUrl: './aboutus.component.html'
})
export class AboutUsComponent {

    visibleMember: number = -1;
    
}
