export interface File {
    name?: string;
    image?: string;
    date?: string;
    fileSize?: string;
}